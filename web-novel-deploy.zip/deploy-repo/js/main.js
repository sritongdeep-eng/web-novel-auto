// The Veridian Protocol — Static Site Navigation

const chapters = [
  { id: 01, title: "CHAPTER 1 — The Glitch in the Blood", file: "01-the-glitch-in-the-blood.md" },
  { id: 02, title: "CHAPTER 2 — The Crimson Circuit", file: "02-the-crimson-circuit.md" },
  { id: 03, title: "CHAPTER 3 — Fragments of the Old World", file: "03-fragments-of-the-old-world.md" },
  { id: 04, title: "CHAPTER 4 — The Witch of Sector 7", file: "04-the-witch-of-sector-7.md" },
  { id: 05, title: "CHAPTER 5 — Protocol Zero", file: "05-protocol-zero.md" },
  { id: 06, title: "CHAPTER 6 — The Blood Network", file: "06-the-blood-network.md" },
  { id: 07, title: "CHAPTER 7 — Echoes in the Static", file: "07-echoes-in-the-static.md" },
  { id: 08, title: "CHAPTER 8 — The Veridian Core", file: "08-the-veridian-core.md" },
  { id: 09, title: "CHAPTER 9 — Sacrifice Protocol", file: "09-sacrifice-protocol.md" },
  { id: 10, title: "CHAPTER 10 — New Genesis", file: "10-new-genesis.md" },
  { id: 11, title: "CHAPTER 11 — The Guardian’s First Watch", file: "11-the-guardians-first-watch.md" },
  { id: 12, title: "CHAPTER 12 — The Shadow in the Static", file: "12-the-shadow-in-the-static.md" },
  { id: 13, title: "CHAPTER 13 — The Military Secret", file: "13-the-military-secret.md" },
  { id: 14, title: "CHAPTER 14 — The NORAD Core", file: "14-the-norad-core.md" },
  { id: 15, title: "CHAPTER 15 — The Choice", file: "15-the-choice.md" },
  { id: 16, title: "CHAPTER 16 — The Void Walker", file: "16-the-void-walker.md" },
  { id: 17, title: "CHAPTER 17 — The First Server", file: "17-the-first-server.md" },
  { id: 18, title: "CHAPTER 18 — The Merge", file: "18-the-merge.md" },
  { id: 19, title: "CHAPTER 19 — The First Contact", file: "19-the-first-contact.md" },
  { id: 20, title: "CHAPTER 20 — The Bridge Between Worlds", file: "20-the-bridge-between-worlds.md" },
];


let currentChapter = 0;

function renderChapterList() {
  const list = document.getElementById('chapter-list');
  list.innerHTML = '';

  chapters.forEach((ch, idx) => {
    const li = document.createElement('li');
    li.textContent = ch.title;
    li.dataset.index = idx;
    if (idx === currentChapter) {
      li.classList.add('active');
    }
    li.addEventListener('click', () => loadChapter(idx));
    list.appendChild(li);
  });
}

async function loadChapter(index) {
  if (index < 0 || index >= chapters.length) return;

  currentChapter = index;
  const chapter = chapters[index];

  try {
    const response = await fetch(`/content/chapters/${chapter.file}`);
    const markdown = await response.text();

    const contentDiv = document.getElementById('chapter-content');
    contentDiv.innerHTML = marked.parse(markdown);

    document.getElementById('prev-chapter').disabled = index === 0;
    document.getElementById('next-chapter').disabled = index === chapters.length - 1;

    renderChapterList();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } catch (error) {
    document.getElementById('chapter-content').innerHTML = `
      <h1>${chapter.title}</h1>
      <p><em>Chapter content loading...</em></p>
    `;
  }
}

document.getElementById('prev-chapter').addEventListener('click', () => {
  if (currentChapter > 0) loadChapter(currentChapter - 1);
});

document.getElementById('next-chapter').addEventListener('click', () => {
  if (currentChapter < chapters.length - 1) loadChapter(currentChapter + 1);
});

// Initialize
renderChapterList();
loadChapter(0);
